<?php

return [
    'user.passwordResetTokenExpire' => 3600,
    'supportEmail' => 'main.triple@yandex.ru',
    'bsVersion' => '4.x',
];
