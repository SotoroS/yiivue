<template>
    <div>
        <router-view></router-view>
    </div>
</template>

<script>
    export default {
        name: 'vue-index',
    }
</script>

<style>
    @import url('https://fonts.googleapis.com/css?family=Roboto');
</style>
