<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=yiivue',
    'username' => 'root',
    'password' => 'YES',
    'charset' => 'utf8',
];
